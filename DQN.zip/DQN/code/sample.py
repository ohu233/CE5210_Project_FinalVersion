'''
爬虫获取实时数据（前期数据不足？）
数据保存到csv
当前批次数据进入经验池并训练
输出当前批次分配结果
更新模型

待完善：
整理一下逻辑
从main里整合一些内容
通机器学习得到相似性
同一条线路需要避免多次变动
Longitude，Latitude，Estimated Arrival三个变量未使用，直接使用了Actual Arrival（推测出的）作为到达时间
动作空间仅有两个动作：停靠到泊位1或泊位2，需要丰富动作空间
结合机器学习的bus到达相似度判断?存在坐标0，0但是有预计到达时间的数据

1. 状态空间的增强

目前的状态空间包含了泊位状态和即将到达的车辆信息，但可以考虑增加更多的环境信息来增强模型的表现力：

	•	排队长度：除了当前泊位的状态，状态空间中还可以加入每个泊位队列的排队长度信息，以便模型更好地理解系统的压力情况。
	•	剩余服务时间：泊位中车辆的剩余服务时间也是重要的状态，可以帮助模型更好地做出调度决策。
	•	历史数据：考虑增加之前的历史观测数据（例如过去5秒的泊位状态、车辆到达情况等），这能让模型捕捉到更长时间范围内的状态变化趋势。

2. 动作空间的扩展

目前的动作空间只包含泊位分配的选择（0和1表示将车辆分配到泊位1或泊位2）。为了更好地处理复杂的调度场景，可以考虑扩展动作空间：

	•	排队等待动作：当前没有直接实现让车辆排队等待的动作（虽然设计了相关的代码逻辑）。可以将“排队”动作正式引入到动作空间中，让模型决定是否将车辆送入排队队列，而不是立即分配泊位。

3. 奖励机制的改进

奖励机制在强化学习中至关重要。现有的奖励机制基于泊位利用率和排队长度，但还可以增加更多的考量因素，以进一步优化系统的表现：

	•	不同服务类型的奖励调整：对于不同服务类型或不同时间段的车辆，当前使用了参数（alpha、beta等）来调整服务时间，但没有显式地在奖励中体现其优先级。可以为高优先级的车辆（例如高峰时间段或特殊路线）设置额外奖励，以鼓励模型优先处理它们。
	•	排队长度惩罚：当前对排队进行了惩罚，但可以引入动态惩罚机制。例如，根据当前的排队长度设置不同级别的惩罚，当排队长度超过某个临界点时，惩罚逐渐加重。
	•	泊位间隔的奖励：可以鼓励模型让相同线路或相似类型的车辆尽量停在同一泊位或附近的泊位，以减少不必要的调度成本。

4. DQN算法的优化

虽然DQN在很多问题上表现良好，但它也有一些局限性，尤其在复杂的、多连续变量的环境中。可以考虑以下强化学习算法的改进：

	•	优先经验回放（Prioritized Experience Replay）：DQN中的经验回放缓冲区是随机采样的，但有时某些经验对模型的学习更重要。可以实现优先级回放，让模型优先学习那些带有高TD误差（即学习价值高）的经验样本。
	•	Double DQN：标准的DQN算法容易导致过估计Q值的问题。可以使用Double DQN来减少这种问题，提升模型的稳定性。
	•	Dueling DQN：这个变体通过将Q值分解为状态价值函数（V）和优势函数（Advantage Function），能够帮助模型更有效地学习哪些动作在特定状态下更优。

5. 训练超参数调整

	•	探索与利用平衡：当前模型可能在早期学习阶段需要更强的探索能力，建议在训练过程中逐渐衰减epsilon（探索率），从高探索率（例如0.9）逐渐衰减到较低值（例如0.05）。
	•	目标网络更新频率：目标网络更新频率可以再进行微调，或者加入软更新策略（Soft Updates），使目标网络更新更加平滑，减少训练过程中的不稳定性。
	•	学习率和批次大小：可以进一步调节学习率和批次大小，找到适合当前环境的最佳组合。通常，较小的学习率会使得模型学习更加稳定，但可能需要更长时间的训练。

6. 更复杂的调度逻辑

	•	多车辆同时到达处理：当前的逻辑是逐步处理车辆的到达，但现实中可能会出现多个车辆在同一时间段到达的情况。可以引入一种批量处理的机制，让模型同时为多个车辆决策调度策略。
	•	不同泊位分配策略的实验：目前是按照固定的规则进行泊位调度，可以考虑引入一些基于优先级的泊位分配策略，例如基于车辆负载、到达时间、服务类型等，优先为某些车辆分配最佳泊位。

8. 业务层面的改进

	•	泊位数量动态调整：现实中泊位的数量和服务速度可以根据需求动态调整。可以尝试将泊位数量作为一种动态状态，由模型自动调整泊位数量，从而进一步优化泊位利用率。
	•	服务时间自动学习：当前服务时间是通过一组参数（alpha、beta等）手动调节的。可以尝试使用机器学习模型自动学习这些参数，或者引入更加复杂的服务时间计算方式，如基于历史数据的预测模型。
'''
import numpy as np
import pandas as pd
import random
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
from datetime import datetime
import requests
import csv
import time
from datetime import datetime
#from Crawler import BusCrawler

# DQN 网络结构
class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# 经验回放池
class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return np.array(states), actions, rewards, np.array(next_states), dones

    def __len__(self):
        return len(self.buffer)

# DQN 代理
class DQNAgent:
    def __init__(self, state_dim, action_dim):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.epsilon = EPSILON_START
        self.steps_done = 0
        self.memory = ReplayBuffer(BUFFER_CAPACITY)

        # 主网络和目标网络
        self.policy_net = DQN(state_dim, action_dim)
        self.target_net = DQN(state_dim, action_dim)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()  # 目标网络不参与训练

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=LR)

    def select_action(self, state):
        self.epsilon = EPSILON_END + (EPSILON_START - EPSILON_END) * np.exp(-1. * self.steps_done / EPSILON_DECAY)
        self.steps_done += 1
        if random.random() > self.epsilon:
            with torch.no_grad():
                return self.policy_net(torch.FloatTensor(state)).argmax().item()
        else:
            return random.randrange(self.action_dim)

    def update(self):
        if len(self.memory) < BATCH_SIZE:
            return
        states, actions, rewards, next_states, dones = self.memory.sample(BATCH_SIZE)

        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions).unsqueeze(1)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(next_states)
        dones = torch.FloatTensor(dones)

        # Q(s_t, a)
        q_values = self.policy_net(states).gather(1, actions).squeeze()

        # max_a' Q(s_{t+1}, a')
        next_q_values = self.target_net(next_states).max(1)[0]
        next_q_values[dones == 1] = 0.0
        target_q_values = rewards + GAMMA * next_q_values

        # 计算损失并反向传播
        loss = nn.MSELoss()(q_values, target_q_values.detach())
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def update_target_net(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

    # 保存模型
    def save(self, policy_path='dqn_policy_net.pth', target_path='dqn_target_net.pth'):
        torch.save(self.policy_net.state_dict(), policy_path)
        torch.save(self.target_net.state_dict(), target_path)

    # 加载模型
    def load(self, policy_path='dqn_policy_net.pth', target_path='dqn_target_net.pth'):
        self.policy_net.load_state_dict(torch.load(policy_path))
        self.target_net.load_state_dict(torch.load(target_path))


# 模拟公交环境类
class BusEnvironment:
    def __init__(self, data):
        # 初始化泊位容量、数量和服务时间
        self.capacity = 2
        self.bay_num = 2
        self.service_time = 40
        # 数据加载
        self.data = data
        self.current_collect_time_index = 0


        # 时间步长
        self.time_step = pd.Timedelta(seconds=1)

        # 初始化环境状态和等待队列
        self.current_step = 0
        self.waiting_queue = {0: [], 1: []}
        self.current_time = self.data['EstimatedArrival'].min()

        # 动作空间定义：泊位分配，仅包含 0 和 1，分别表示 bay1 和 bay2
        self.action_space = [0, 1]

        # 状态空间定义：包含泊位状态和车辆信息
        self.state_dim = 10  # 4 个泊位状态 + 6 个车辆信息
        self.state = self.reset()   # 初始化状态
    
    def reset(self):
        # 重置泊位状态、服务时间和等待队列
        self.bays = [[None for _ in range(self.capacity)] for _ in range(self.bay_num)]
        self.remaining_service_time = [[0 for _ in range(self.capacity)] for _ in range(self.bay_num)]

        # 获取当前批次数据
        self.current_time = self.data['EstimatedArrival'].min()
        self.current_step = 0
        self.waiting_queue = {0: [], 1: []}

        # 返回初始状态观察值
        return self._next_observation()

    def _next_observation(self):
        # 获取泊位状态信息
        bay_status = np.array(
            [1 if self.bays[i][j] is not None else 0 for i in range(self.bay_num) for j in range(self.capacity)],
            dtype=np.float32
        )

        # 检查是否有车辆到达当前时间点
        if (self.current_step < len(self.data) and 
            self.data.iloc[self.current_step]['EstimatedArrival'] <= self.current_time):
            next_vehicle = self.data.iloc[self.current_step]
            vehicle_info = np.array([
                next_vehicle['ServiceNo'], next_vehicle['Load'], next_vehicle['Type'],
                next_vehicle['DayOfWeek'], next_vehicle['Latitude'], next_vehicle['Longitude']
            ], dtype=np.float32)
        else:
            vehicle_info = np.array([0, 0, 0, 0, 0, 0], dtype=np.float32)

        # 合并泊位状态和车辆信息
        return np.concatenate([bay_status, vehicle_info])
    
    def step(self, action):
        # 步进方法：根据动作更新泊位状态、计算奖励、并推进时间
        reward = 0
        terminated = False

        if (self.current_step < len(self.data) and 
            self.data.iloc[self.current_step]['EstimatedArrival'] <= self.current_time):
            current_vehicle = self.data.iloc[self.current_step]
            a, b, _, _ = self.para(current_vehicle)
            vehicle_info = {
                'ServiceNo': current_vehicle['ServiceNo'],
                'Load': current_vehicle['Load'],
                'Type': current_vehicle['Type'],
                'DayOfWeek': current_vehicle['DayOfWeek'],
                'Latitude': current_vehicle['Latitude'],
                'Longitude': current_vehicle['Longitude'],
                'VehCode': current_vehicle['VehCode'],
                'CollectTime': current_vehicle['CollectTime']
            }
            self.current_step += 1

            if action in [0, 1]:
                if None in self.bays[action]:
                    empty_spot = self.bays[action].index(None)
                    if empty_spot == 0 and self.bays[action][1] is not None:
                        reward -= 10
                    self.bays[action][empty_spot] = vehicle_info
                    self.remaining_service_time[action][empty_spot] = int(self.service_time * a * b)
                else:
                    self.waiting_queue[action].append(current_vehicle.to_dict())

        for i in range(self.bay_num):
            for j in range(self.capacity):
                if self.remaining_service_time[i][j] > 0:
                    self.remaining_service_time[i][j] -= 1
                if self.remaining_service_time[i][j] == 0 and self.bays[i][j] is not None:
                    self.bays[i][j] = None
                    if len(self.waiting_queue[i]) > 0:
                        next_in_queue = self.waiting_queue[i].pop(0)
                        self.bays[i][j] = next_in_queue
                        a, b, _, _ = self.para(next_in_queue)
                        self.remaining_service_time[i][j] = int(self.service_time * a * b)

        self.current_time += self.time_step
        reward = self.reward()

        return self._next_observation(), reward, terminated
    
    def para(self, veh):
        # 服务时间调整参数
        morning_peak = (datetime.strptime('07:00', '%H:%M').time(), datetime.strptime('09:00', '%H:%M').time())
        evening_peak = (datetime.strptime('17:00', '%H:%M').time(), datetime.strptime('19:00', '%H:%M').time())

        load, type, dayofweek, collecttime = veh['Load'], veh['Type'], veh['DayOfWeek'], pd.to_datetime(veh['CollectTime']).time()

        alpha = 0.9 if type == '1' else 1.1
        beta = 0.9 if load == '1' else 1 if load == '2' else 1.1
        gamma = 0.9 if dayofweek in ['6', '7'] else 1
        theta = 1.5 if (morning_peak[0] <= collecttime <= morning_peak[1]) or (evening_peak[0] <= collecttime <= evening_peak[1]) else 1

        return alpha, beta, gamma, theta

    def reward(self):
        '''
        奖励计算（计算持续性奖励，即每秒都需要计算的奖励，仅包括奖励设置的3，4）
        理解成奖励的一部分

        奖励设置
        1.离开 <- area1 area2 <- area1 area2 <- 到达
                  0    1    该情况应当给予惩罚：由于后到达的车辆不好进入靠前的泊位
        
        2.同一路线尽量减少变动

        3.bay1排队超过一定长度后进行惩罚
        
        4.info作为系数去影响奖励
        '''
        # 奖励计算，包括泊位使用奖励和排队惩罚
        reward = 0
        for i in range(self.bay_num):
            for j in range(self.capacity):
                if self.bays[i][j] is not None:
                    alpha, beta, _, _ = self.para(self.bays[i][j])
                    reward += beta * 20
        for i in range(self.bay_num):
            for bus in self.waiting_queue[i]:
                alpha, beta, gamma, theta = self.para(bus)
                reward -= 10 * alpha * beta * gamma * theta

        return float(reward)

# 批量数据获取和分配生成
def generate_batch_data(env, batch_size):
    batch_data = []
    for _ in range(batch_size):
        state = env.reset().flatten()  # 获取初始状态并展平
        batch_data.append(state)
    return np.array(batch_data)

def allocate_batch(agent, batch_data):
    allocation_results = []
    with torch.no_grad():
        for state in batch_data:
            action = agent.policy_net(torch.FloatTensor(state)).argmax().item()
            allocation_results.append(action)
    return allocation_results


# 自定义奖励函数
def reward_func(state, action, next_state):
    reward = -np.abs(next_state - action).sum()  # 状态与目标值的差异
    return reward


# 使用新数据批量更新模型
def update_model_with_batch(agent, env, batch_data, allocation_results, reward_func):
    for state, action in zip(batch_data, allocation_results):
        # 获取下一状态和奖励
        next_state, reward, done = env.step(action)
        next_state = next_state.flatten()  # 将下一状态展平为1维向量

        # 自定义奖励函数计算奖励
        reward = reward_func(state, action, next_state)

        # 将经验存入经验回放池
        agent.memory.push(state, action, reward, next_state, done)

    # 使用新的数据优化模型
    agent.update()

# 超参数
GAMMA = 0.99           # 折扣因子
BATCH_SIZE = 32        # 批次大小
BUFFER_CAPACITY = 1000 # 经验回放池容量
LR = 0.001             # 学习率
EPSILON_START = 1.0    # 初始探索率
EPSILON_END = 0.01     # 最低探索率
EPSILON_DECAY = 500    # 探索率衰减

'''
# 使用API信息初始化采集器
api_key = "LhPnk7kfTDqb849G9KuhqA=="
urls = [
    "https://datamall2.mytransport.sg/ltaodataservice/v3/BusArrival?BusStopCode=04167",
    "https://datamall2.mytransport.sg/ltaodataservice/v3/BusArrival?BusStopCode=04168"
]
collector = BusCrawler(api_key, urls)
#data = collector.collect()
'''

#暂时用已有数据测试代码
excel_data = pd.read_excel('Data/preprocessed.xlsx')
unicode = excel_data['CollectTime'].unique()

# 主训练-优化循环
batch_size = 10  # 每批次数据的大小
num_iterations = 100  # 总迭代次数
env = BusEnvironment(num_lines=17, num_stops=50)
state_dim = 17 * 50  # 与环境的状态维度一致
action_dim = 5  # 动作空间的维度可以根据实际需求调整
agent = DQNAgent(state_dim, action_dim)

for iteration in range(num_iterations):
    # 获取一批新数据
    data = excel_data[excel_data['CollectTime'] == unicode[iteration]]
    batch_data = generate_batch_data(data)

    # 使用模型生成合理的分配结果
    allocation_results = allocate_batch(agent, batch_data)

    # 更新模型，将新数据及其分配结果加入数据集
    update_model_with_batch(agent, env, batch_data, allocation_results, reward_func)

    # 每隔一定的迭代次数保存模型
    if iteration % 10 == 0:
        agent.save()
        print(f"Iteration {iteration}, Model saved.")

    print(f"Iteration {iteration} completed.")