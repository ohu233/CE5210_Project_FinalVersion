import pandas as pd

data = pd.read_excel('Data/preprocessed.xlsx')
unicode = data['CollectTime'].unique()
print(unicode[0])