import pandas as pd
import random

# 假设 service_time 为每辆车服务的时间，capacity 为每个泊位位置的容量，bay_num 为泊位数
service_time = 180  # 服务时间（秒）
capacity = 2  # 每个泊位位置的容量
bay_num = 2  # 泊位数

# 初始化泊位和等待队列
bays = [[None] * capacity for _ in range(bay_num)]
waiting_queue = [[] for _ in range(bay_num)]  # 为每个泊位设置独立的等待队列

# 加载数据
df = pd.read_excel('Data/preprocessed(simple).xlsx')
df = df.head(20)

# 用于追踪上一次输出的时间
last_event_time = None

def print_status(event_time):
    """打印泊位和等待队列的状态"""
    print(f"Event Time: {event_time}")
    for bay_index, bay in enumerate(bays, 1):
        for slot_index, vehicle in enumerate(bay, 1):
            print(f"Bay {bay_index} Slot {slot_index}: {vehicle}")
        print('-' * 40)
    for queue_index, queue in enumerate(waiting_queue, 1):
        print(f"Waiting Queue {queue_index}: {queue}")
    print('#' * 40)

# 遍历每辆车
for index, row in df.iterrows():
    vehicle_info = {
        'ServiceNo': row['ServiceNo'],
        'Load': row['Load'],
        'Type': row['Type'],
        'DayOfWeek': row['DayOfWeek'],
        'Latitude': row['Latitude'],
        'Longitude': row['Longitude'],
        'VehCode': row['VehCode'],
        'ActualArrival': row['ActualArrival'],
        'AllocatedTime': None,  # 新增属性，用于记录进入泊位的时间
        'DepartureTime': None
    }
    
    # 随机选择 action（0 或 1），表示车辆的目标泊位
    action = random.choice([0, 1])

    # 检查并释放已完成服务的车辆（仅限于选定的泊位）
    for slot_index in range(capacity):
        if bays[action][slot_index] and bays[action][slot_index]['DepartureTime'] <= vehicle_info['ActualArrival']:
            last_event_time = bays[action][slot_index]['DepartureTime']
            bays[action][slot_index] = None  # 释放泊位

            # 释放泊位后，检查该泊位的等待队列并分配给等待队列中的第一个车辆
            if waiting_queue[action]:
                next_bus = waiting_queue[action].pop(0)
                next_bus['AllocatedTime'] = last_event_time  # 设置进入泊位的时间
                next_bus['DepartureTime'] = next_bus['AllocatedTime'] + pd.Timedelta(seconds=service_time)
                bays[action][slot_index] = next_bus
                print_status(last_event_time)  # 立即打印状态

    # 检查选定泊位是否有空位
    allocated = False
    if None in bays[action]:
        empty_slot = bays[action].index(None)
        
        # 如果该泊位的等待队列有车辆，优先处理等待队列中的车辆
        if waiting_queue[action]:
            next_bus = waiting_queue[action].pop(0)
            next_bus['AllocatedTime'] = max(next_bus['ActualArrival'], vehicle_info['ActualArrival'])
        else:
            next_bus = vehicle_info
            next_bus['AllocatedTime'] = next_bus['ActualArrival']

        # 设置离开时间
        next_bus['DepartureTime'] = next_bus['AllocatedTime'] + pd.Timedelta(seconds=service_time)
        bays[action][empty_slot] = next_bus
        last_event_time = next_bus['AllocatedTime']
        print_status(last_event_time)  # 打印状态变化
        allocated = True

    if not allocated:
        # 如果目标泊位没有空位，将当前车辆加入选定的等待队列
        waiting_queue[action].append(vehicle_info)
        last_event_time = vehicle_info['ActualArrival']
        print_status(last_event_time)  # 立即打印状态