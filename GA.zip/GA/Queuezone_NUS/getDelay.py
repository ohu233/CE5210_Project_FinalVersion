import pandas as pd
from collections import deque
import matplotlib.pyplot as plt

df = pd.read_csv('data/preproccessed_GA.csv')

# Transform the DateTime column to Date and TotalSeconds in 24h
df['DateUseInDelayCauc'] = df['DateTime'].str[:10]
df['TotalSeconds'] = df['DateTime'].str[11:13].astype(int) * 3600 \
                     + df['DateTime'].str[14:16].astype(int) * 60 \
                     + df['DateTime'].str[17:19].astype(int)

grouped = df.groupby('DateUseInDelayCauc')

dateDelayPair = []

for date, group in grouped:

    queue = deque()  # Queue for waiting vehicles
    delay = 0

    # each day
    for _, row in group.iterrows():
        arrival_time = row['TotalSeconds']
        queue.append(arrival_time)

    # Two service zones, serviceZone[i] = K, means the i-th service zone has a veh will left at K-th second
    serviceZone = [queue[0]+60, queue[1]+60]
    queue.popleft()
    queue.popleft()

    # Process the queue
    while queue:
        arrival_time = queue.popleft()

        # Find the service zone to enter
        # 1. the min_left_time < arrival_time, no need to wait, delay = 0
        # 2. the min_left_time >= arrival_time, wait until the min_left_time
        min_left_time, min_idx = min(serviceZone), serviceZone.index(min(serviceZone))
        if min_left_time >= arrival_time:
            delay += min_left_time - arrival_time
        # Update the service zone
        serviceZone[min_idx] = arrival_time + 60

    dateDelayPair.append((date, delay))

# Plot the results
dates = [date for date, _ in dateDelayPair]
delays = [delay / 60 for _, delay in dateDelayPair]  # Convert delay to minutes

plt.figure(figsize=(10, 5))
plt.bar(dates, delays, color='blue')
plt.xlabel('Date')
plt.ylabel('Total Delay (minutes)')
plt.title('Total Delay per Day')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('figur/total_delay_per_day.png')