import pandas as pd
import re

df = pd.read_excel('BusData04167.xlsx')


df = df.drop_duplicates(subset=['Date', 'ServiceNo', 'ActualArrival'])
df = df.dropna(subset=['ActualArrival', 'Date'])

df['VehCode'] = df['VehCode'].apply(lambda x: '{:.6f}'.format(x))
df['VehCode'] = df['VehCode'].apply(lambda x: int(float(x)))
df['VehCode'] = df['VehCode'].astype(str)

df['Date'] = pd.to_datetime(df['Date'])
df['TimeDelta'] = pd.to_timedelta(df['ActualArrival'])
df['DateTime'] = df['Date'] + df['TimeDelta']
 
df['ServiceNo'] = df['ServiceNo'].apply(lambda x: re.sub(r'[A-Za-z]', '', x))

df.to_excel('preproccessed_GA.xlsx', index=False)