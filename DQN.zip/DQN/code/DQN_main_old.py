'''
待完善：
整理一下逻辑
从main里整合一些内容
通机器学习得到相似性
同一条线路需要避免多次变动
Longitude，Latitude，Estimated Arrival三个变量未使用，直接使用了Actual Arrival（推测出的）作为到达时间
动作空间仅有两个动作：停靠到泊位1或泊位2，需要丰富动作空间
结合机器学习的bus到达相似度判断?

1. 状态空间的增强

目前的状态空间包含了泊位状态和即将到达的车辆信息，但可以考虑增加更多的环境信息来增强模型的表现力：

	•	排队长度：除了当前泊位的状态，状态空间中还可以加入每个泊位队列的排队长度信息，以便模型更好地理解系统的压力情况。
	•	剩余服务时间：泊位中车辆的剩余服务时间也是重要的状态，可以帮助模型更好地做出调度决策。
	•	历史数据：考虑增加之前的历史观测数据（例如过去5秒的泊位状态、车辆到达情况等），这能让模型捕捉到更长时间范围内的状态变化趋势。

2. 动作空间的扩展

目前的动作空间只包含泊位分配的选择（0和1表示将车辆分配到泊位1或泊位2）。为了更好地处理复杂的调度场景，可以考虑扩展动作空间：

	•	排队等待动作：当前没有直接实现让车辆排队等待的动作（虽然设计了相关的代码逻辑）。可以将“排队”动作正式引入到动作空间中，让模型决定是否将车辆送入排队队列，而不是立即分配泊位。

3. 奖励机制的改进

奖励机制在强化学习中至关重要。现有的奖励机制基于泊位利用率和排队长度，但还可以增加更多的考量因素，以进一步优化系统的表现：

	•	不同服务类型的奖励调整：对于不同服务类型或不同时间段的车辆，当前使用了参数（alpha、beta等）来调整服务时间，但没有显式地在奖励中体现其优先级。可以为高优先级的车辆（例如高峰时间段或特殊路线）设置额外奖励，以鼓励模型优先处理它们。
	•	排队长度惩罚：当前对排队进行了惩罚，但可以引入动态惩罚机制。例如，根据当前的排队长度设置不同级别的惩罚，当排队长度超过某个临界点时，惩罚逐渐加重。
	•	泊位间隔的奖励：可以鼓励模型让相同线路或相似类型的车辆尽量停在同一泊位或附近的泊位，以减少不必要的调度成本。

4. DQN算法的优化

虽然DQN在很多问题上表现良好，但它也有一些局限性，尤其在复杂的、多连续变量的环境中。可以考虑以下强化学习算法的改进：

	•	优先经验回放（Prioritized Experience Replay）：DQN中的经验回放缓冲区是随机采样的，但有时某些经验对模型的学习更重要。可以实现优先级回放，让模型优先学习那些带有高TD误差（即学习价值高）的经验样本。
	•	Double DQN：标准的DQN算法容易导致过估计Q值的问题。可以使用Double DQN来减少这种问题，提升模型的稳定性。
	•	Dueling DQN：这个变体通过将Q值分解为状态价值函数（V）和优势函数（Advantage Function），能够帮助模型更有效地学习哪些动作在特定状态下更优。

5. 训练超参数调整

	•	探索与利用平衡：当前模型可能在早期学习阶段需要更强的探索能力，建议在训练过程中逐渐衰减epsilon（探索率），从高探索率（例如0.9）逐渐衰减到较低值（例如0.05）。
	•	目标网络更新频率：目标网络更新频率可以再进行微调，或者加入软更新策略（Soft Updates），使目标网络更新更加平滑，减少训练过程中的不稳定性。
	•	学习率和批次大小：可以进一步调节学习率和批次大小，找到适合当前环境的最佳组合。通常，较小的学习率会使得模型学习更加稳定，但可能需要更长时间的训练。

6. 更复杂的调度逻辑

	•	多车辆同时到达处理：当前的逻辑是逐步处理车辆的到达，但现实中可能会出现多个车辆在同一时间段到达的情况。可以引入一种批量处理的机制，让模型同时为多个车辆决策调度策略。
	•	不同泊位分配策略的实验：目前是按照固定的规则进行泊位调度，可以考虑引入一些基于优先级的泊位分配策略，例如基于车辆负载、到达时间、服务类型等，优先为某些车辆分配最佳泊位。

8. 业务层面的改进

	•	泊位数量动态调整：现实中泊位的数量和服务速度可以根据需求动态调整。可以尝试将泊位数量作为一种动态状态，由模型自动调整泊位数量，从而进一步优化泊位利用率。
	•	服务时间自动学习：当前服务时间是通过一组参数（alpha、beta等）手动调节的。可以尝试使用机器学习模型自动学习这些参数，或者引入更加复杂的服务时间计算方式，如基于历史数据的预测模型。
'''
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
from stable_baselines3 import DQN
from stable_baselines3.common.env_checker import check_env
import time
from datetime import datetime

class BusEnv(gym.Env):
    def __init__(self, data):
        super(BusEnv, self).__init__()
        # 容量 泊位数量 初始服务时间
        self.capacity = 2
        self.bay_num = 2
        self.service_time = 40
        '''
        action space动作空间:
        0->bay1, 1->bay2
        暂时只有0和1
        2->wait in bay1 queue, 3->wait in bay2 queue
        '''
        self.action_space = spaces.Discrete(2)
        '''
        observation_space状态空间:
        bay1_1, bay1_2, bay2_1, bay2_2, ServiceNo, Load, Type, DayOfWeek, Latitude, Longitude
        '''
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0], dtype=np.float32), 
            high=np.array([1, 1, 1, 1, 17, 3, 2, 7, 1.4 ,104], dtype=np.float32), 
            dtype=np.float32
        )
        #加载数据
        self.data = data
        #以Collect Time为索引
        self.collect_times = self.data['CollectTime'].unique()
        self.current_collect_time_index = 0
        #分批次的数据
        self.batch_data = self.data[self.data['CollectTime'] == self.collect_times[self.current_collect_time_index]]
        self.current_time = self.batch_data['EstimatedArrival'].min()
        #以秒为单位推进
        self.time_step = pd.Timedelta(seconds=1)
        #初始化
        self.current_step = 0
        self.waiting_queue = {0: [], 1: []}
        self.total_reward = 0
        self.reset()

    def reset(self, seed=None, options=None):
        '''
        重制环境用于下一次训练
        '''
        #随机种子
        super().reset(seed=seed)
        if seed is not None:
            np.random.seed(seed)
        #清空泊位
        self.bays = [[None for _ in range(self.capacity)] for _ in range(self.bay_num)]
        #清空服务时间
        self.remaining_service_time = [[0 for _ in range(self.capacity)] for _ in range(self.bay_num)]
        # 获取当前 collect_time 对应的车辆数据
        self.batch_data = self.data[self.data['CollectTime'] == self.collect_times[self.current_collect_time_index]]
        self.current_time = self.batch_data['EstimatedArrival'].min()
        self.current_step = 0
        self.waiting_queue = {0: [], 1: []}
        # 重置每个批次的奖励值
        self.batch_reward = 0  
        self.service_time = 40

        return self._next_observation(), {}

    def _next_observation(self):
        '''
        获取车辆的观测值
        '''
        #二维数组判断bays中是否存在内容，即泊位状态
        bay_status = np.array([1 if self.bays[i][j] is not None else 0 for i in range(self.bay_num) for j in range(self.capacity)], dtype=np.float32)
        #如果当前步<当前批次的长度 and 当前步的EstimatedArrival<当前时间，即当前批次未处理完并且有车辆到达
        if self.current_step < len(self.batch_data) and self.batch_data.iloc[self.current_step]['EstimatedArrival'] <= self.current_time:
            #当前时间步作为下一辆，并获取其信息
            next_vehicle = self.batch_data.iloc[self.current_step]
            vehicle_info = np.array([next_vehicle['ServiceNo'], 
                                     next_vehicle['Load'], 
                                     next_vehicle['Type'],
                                     next_vehicle['DayOfWeek'],
                                     next_vehicle['Latitude'],
                                     next_vehicle['Longitude']],
                                     dtype=np.float32)
            #否则信息设置为0
        else:
            vehicle_info = np.array([0, 0, 0, 0, 0, 0], dtype=np.float32)
        #合并泊位状态和车辆信息
        return np.concatenate([bay_status, vehicle_info])

    def para(self, veh):
        '''
        获取调整服务时间的参数
        '''
        # 将7点-9点，17点-19点作为早晚高峰时间
        morning_peak_start = datetime.strptime('07:00', '%H:%M').time()
        morning_peak_end = datetime.strptime('09:00', '%H:%M').time()
        evening_peak_start = datetime.strptime('17:00', '%H:%M').time()
        evening_peak_end = datetime.strptime('19:00', '%H:%M').time()

        load = veh['Load']
        type = veh['Type']
        dayofweek = veh['DayOfWeek']
        collecttime = veh['CollectTime']
        collecttime = pd.to_datetime(collecttime, format='%H:%M').time()

        alpha = 0.9 if type == '1' else 1.1   #type para
        beta = 0.9 if load == '1' else 1 if load == '2' else  1.1
        gamma = 0.9 if dayofweek == '6' or dayofweek == '7' else 1
        # 判断 collecttime 是否在高峰时段
        if (morning_peak_start <= collecttime <= morning_peak_end) or (evening_peak_start <= collecttime <= evening_peak_end):
            theta = 1.5
        else:
            theta = 1
        
        return alpha, beta, gamma, theta

    def reward(self):
        '''
        奖励计算（计算持续性奖励，即每秒都需要计算的奖励，仅包括奖励设置的3，4）
        理解成奖励的一部分

        奖励设置
        1.离开 <- area1 area2 <- area1 area2 <- 到达
                  0    1    该情况应当给予惩罚：由于后到达的车辆不好进入靠前的泊位
        
        2.同一路线尽量减少变动

        3.bay1排队超过一定长度后进行惩罚
        
        4.info作为系数去影响奖励
        '''
        reward = 0
        # 奖励泊位中的车辆（实际上就是奖励泊位使用率）
        for i in range(self.bay_num):
            for j in range(self.capacity):
                if self.bays[i][j] is not None:
                    vehicle_info = self.bays[i][j]
                    alpha, beta, gamma, theta = self.para(vehicle_info)
                    reward += beta * 20
        # 排队惩罚（暂时设定）
        for i in range(self.bay_num):
            for bus in self.waiting_queue[i]:
                alpha, beta, gamma, theta = self.para(bus)
                reward -= 10 * alpha * beta * gamma * theta

        return float(reward)

    def step(self, action):
        #初始化
        reward = 0
        terminated = False
        truncated = False
        #如果当前时间步<当前批次的长度 and 当前时间步的EstimatedArrival<当前时间 即当前批次未处理完并且有车辆到达
        if self.current_step < len(self.batch_data) and self.batch_data.iloc[self.current_step]['EstimatedArrival'] <= self.current_time:
            #获取当前车辆及信息
            current_vehicle = self.batch_data.iloc[self.current_step]
            a, b, _, _ = self.para(current_vehicle)
            #获取车辆信息
            vehicle_info = {
                'ServiceNo': current_vehicle['ServiceNo'],
                'Load': current_vehicle['Load'],
                'Type': current_vehicle['Type'],
                'DayOfWeek': current_vehicle['DayOfWeek'],
                'Latitude': current_vehicle['Latitude'],
                'Longitude': current_vehicle['Longitude'],
                'VehCode' : current_vehicle['VehCode'],
                'CollectTime' : current_vehicle['CollectTime']
            }
            #当前步数+1
            self.current_step += 1
            #进行动作选择，当前为两个动作
            if action == 0 or action == 1:
                #判断是否进行排队
                #如果泊位为空，则直接进入
                if None in self.bays[int(action)]:
                    #选取分配的泊位后，寻找停靠
                    empty_spot = self.bays[int(action)].index(None)
                    #需要避免发生进入前泊位的情况（奖励计算）
                    if empty_spot == 0 and self.bays[int(action)][1] != None:
                        reward = reward - 10

                    #停靠位置添加信息：VehCode
                    self.bays[int(action)][empty_spot] = vehicle_info
                    
                    service_time = int(self.service_time*a*b)
                    #开始倒计时服务时间
                    self.remaining_service_time[int(action)][empty_spot] = service_time
                #否则计入排队队列
                else:
                    self.waiting_queue[int(action)].append(current_vehicle.to_dict())


            #之后需要更改的状态空间，暂时不用管
                '''           
                #此处时设定的额外的动作空间，之后再来处理 
                elif action == 2 or action == 3:
                # Wait in Bay1 or Bay2 queue
                self.waiting_queue[int(action) - 2].append(current_vehicle.to_dict())
                reward = self.reward()  # if waiting
                '''
                
        # 双层for循环遍历四个泊位
        for i in range(self.bay_num):
            for j in range(self.capacity):
                #如果剩余时间不为0，剩余时间-1
                if self.remaining_service_time[i][j] > 0:
                    self.remaining_service_time[i][j] -= 1
                #如果剩余时间为0且泊位非空，即该车辆需要离站
                if self.remaining_service_time[i][j] == 0 and self.bays[i][j] is not None:
                    #清空泊位
                    self.bays[i][j] = None
                    #如果此时还有车辆排队
                    if len(self.waiting_queue[i]) > 0:
                        #删除排队队列的首辆
                        next_in_queue = self.waiting_queue[i].pop(0)
                        #将其加入刚刚空出的泊位中
                        self.bays[i][j] = next_in_queue 
                        a,b,_,_ = self.para(self.bays[i][j])
                        service_time = int(self.service_time*a*b)
                        self.remaining_service_time[i][j] = service_time  # reassign bus
        #时间步+1
        self.current_time += self.time_step
        #计算奖励值
        reward = self.reward()
        # 累计当前批次的奖励
        self.batch_reward += reward

        #如果当前步数大于等于这批数据的长度 and 检查排队队列是否都为空 and 检查剩余服务时间是否清空，即当前批次处理完毕
        if (
    self.current_step >= len(self.batch_data) 
    and all(len(queue) == 0 for queue in self.waiting_queue.values()) 
    and all(time == 0 for row in self.remaining_service_time for time in row)
):
    # 执行相关逻辑
            # 如果批次索引 < 收集数据的总索引，即该数据还未处理完毕
            if self.current_collect_time_index < len(self.collect_times) - 1:
                #索引+1
                self.current_collect_time_index += 1
                # 累积每个批次的总奖励
                self.total_reward += self.batch_reward 
                #检查批次奖励
                #print('CollectTime',self.collect_times[self.current_collect_time_index])
                #print('batch reward:', self.batch_reward)
                # 重置环境到下一个批次
                self.reset()
            else:
                # 所有批次处理完毕，终止环境，返回总奖励
                # 累积最后一个批次的总奖励
                self.total_reward += self.batch_reward
                terminated = True
                # 返回累积的 total_reward
                reward = self.total_reward  
                #print('total reaward:', reward)

        return self._next_observation(), reward, terminated, truncated, {}

    def render(self, mode='human'):
        '''
        用来打印信息
        训练过程中用不到
        '''
        print(f"current time: {self.current_time}")
        for i in range(self.bay_num):
            for j in range(self.capacity):
                baybus = self.bays[i][j]
                if baybus is not None:
                    print(f"bay{i+1} area{j+1}: {baybus['ServiceNo']}")
                else:
                    print(f"bay{i+1} area{j+1}: None")

        print(f"remaining time: {self.remaining_service_time}")
        print("waiting queue:")
        for bay, buses in self.waiting_queue.items():
            print(f" Bay {bay + 1}:")
            for bus in buses:
                print(f"  ServiceNo: {bus['ServiceNo']}, ActualArrival: {bus['ActualArrival']}")
        print('-' * 40)

class BusSimularity():
    '''
    计算各个车辆之间的到达相似性，之后用来替代服务时间
    '''
    def __init__(self):
        pass


# load dataset
data = pd.read_excel('Data/preprocessed.xlsx')
data = data[data['EstimatedArrival'].dt.date == pd.to_datetime('2024-06-18').date()]


# 创建自定义环境实例
env = BusEnv(data)

# 检查环境是否符合 Gym 的接口要求（可选）
check_env(env, warn=True)

# 设置 TensorBoard 日志目录
tensorboard_log_dir = "./dqn_tensorboard/"

# 创建 DQN 模型，指定策略和环境，并自定义经验回放参数
model = DQN(
    "MlpPolicy",
    env,
    verbose=1,
    tensorboard_log=tensorboard_log_dir,
    buffer_size=50000,  # 经验回放缓冲区大小
    batch_size=64,      # 从经验回放中采样的批量大小
    learning_starts=1000,  # 在缓冲区积累了1000个样本之后开始学习
    target_update_interval=500,  # 每隔500步更新目标网络
    train_freq=4,  # 每4个时间步更新一次模型
)

# 训练模型，假设训练 10000 个时间步
model.learn(total_timesteps=10000000, tb_log_name="DQN_BusEnv")

# 保存模型
model.save("Model/DQN_model")


'''
# 初始化自定义环境
env = BusEnv(data)

# 初始化模型，设定探索策略
model = DQN('MlpPolicy', env, verbose=1, learning_starts=1000, train_freq=4, exploration_fraction=0.1, exploration_final_eps=0.05)

# 直接进行自动化训练，按时间步数控制
model.learn(total_timesteps=100000)

# 保存模型（可选）
model.save("Model/DQN_model")


'''
'''
# 初始化自定义环境
env = BusEnv(data)

# 初始化模型
model = DQN('MlpPolicy', env, verbose=1)

# 定义训练的回合数
n_episodes = 2  # 训练回合数

# 手动按回合训练
for episode in range(n_episodes):
    # 重置环境，开始新的回合
    obs, _ = env.reset()
    done = False
    total_episode_reward = 0  # 每个回合的累计奖励

    # 开始一个回合
    while not done:
        # 使用模型预测下一个动作 (训练时应设置 deterministic=False，允许探索)
        action, _ = model.predict(obs, deterministic=False)

        # 执行该动作，获取下一个状态、奖励、是否结束的标志
        obs, reward, terminated, truncated, info = env.step(action)

        # 累积本回合的奖励
        total_episode_reward += reward

        # 检查回合结束的条件
        done = terminated or truncated

    # 每个回合结束时，打印回合信息
    print(f"Episode {episode + 1}/{n_episodes}: Total reward = {total_episode_reward}")

    # 在每个回合结束后进行模型学习
    # 可以通过适当的数据（例如 replay buffer）来更新模型，或者调用 model.learn()
    model.learn(total_timesteps=2048*1000)  # 你可以调整 timesteps 的值来控制更新频率

# 保存模型
model.save("Model/DQN_model")
'''

'''
env = BusEnv(data)

model = DQN.load("Model/DQN_model.zip")

obs, info = env.reset()
for i in range(100):
    action, _states = model.predict(obs, deterministic=True)
    obs, reward, done, trunc, _ = env.step(action)
    env.render()

    time.sleep(0.3)

    if done:
        obs, info = env.reset()

env.close()

'''