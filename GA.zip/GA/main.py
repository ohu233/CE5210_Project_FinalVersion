import torch
import pandas as pd
import random
import logging
from GA import GeneticAlgorithm
from env import RouteAssignmentEnv
from collections import deque
import matplotlib.pyplot as plt

# Set random seed
random.seed(42)
torch.manual_seed(42)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Import data
df = pd.read_excel('preproccessed_GA.xlsx')
df['ActualArrival'] = pd.to_datetime(df['ActualArrival'], format="%H:%M:%S")

busNo = df['ServiceNo'].unique()
busNo.sort()
bus_data = pd.DataFrame({'ServiceNo': busNo})

# Set parameters
alpha = 0.7     # Ratio of berth1' delay
beta = 0.3      # Ratio of berth2' delay
theta = 10       # Ratio of distribution

#training
env = RouteAssignmentEnv(bus_data)
ga = GeneticAlgorithm(env, pop_size=50, generations=20, mutation_rate=0.05, df=df)
berth_1, berth_2, best_fitness = ga.run(alpha, beta, theta)

#plot
ga.plot_best_fitness()

print(f"Best Solution - Berth 1: {berth_1}")
print(f"Best Solution - Berth 2: {berth_2}")
print(f"Best Fitness: {best_fitness}")

berths = [berth_1, berth_2]

for berth in berths:
    berth_df = df[df['ServiceNo'].isin(berth)]
    berth_df = berth_df.sort_values(['DateTime'])
    grouped = berth_df.groupby('Date')
    dateDelayPair = []

    for date, group in grouped:
        queue = deque()
        delay = 0

        for _, row in group.iterrows():
            arrival_time = row['DateTime']
            queue.append(arrival_time)

        serviceZone = [queue[0]+60 * pd.Timedelta(seconds=1), queue[1]+60 * pd.Timedelta(seconds=1)]
        queue.popleft()
        queue.popleft()

        # Process the queue
        while queue:
            arrival_time = queue.popleft()
            min_left_time, min_idx = min(serviceZone), serviceZone.index(min(serviceZone))

            if min_left_time >= arrival_time:
                delay += (min_left_time - arrival_time).total_seconds()

            serviceZone[min_idx] = arrival_time + 60 * pd.Timedelta(seconds=1)

        dateDelayPair.append((date, delay))

    dates = [date for date, _ in dateDelayPair]
    delays = [delay  for _, delay in dateDelayPair]

    plt.figure(figsize=(10, 5))
    plt.bar(dates, delays, color='blue')
    plt.xlabel('Date')
    plt.ylabel('Total Delay (second)')
    plt.title('Total Delay per Day')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig(f'DelayFigure/delay_{berth}.png')
    plt.close()