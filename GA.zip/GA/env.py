import torch
import pandas as pd
import numpy as np
from collections import deque

class RouteAssignmentEnv:
    def __init__(self, bus_data, berth_capacity=2):
        """
        bus_data: DataFrame of routes
        berth_capacity: int, capacity of each berth
        """
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_built() else 'cpu')
        self.bus_data = bus_data
        self.num_buses = len(bus_data)
        self.berth_capacity = berth_capacity
        self.reset()

    def reset(self):
        """
        Resets the environment for a new episode.
        """
        self.berth_1 = []
        self.berth_2 = []
        self.done = False
        return self._get_state()

    def _get_state(self):
        """
        Returns the current state of the environment.
        """
        return len(self.berth_1), len(self.berth_2)

    '''    
    def assign_buses(self, action):
        """
        Randomly select n routes and assign them to berth 1, 
        the remaining routes go to berth 2.
        """
        n = action
        shuffled_buses = self.bus_data.sample(frac=1, random_state=42).reset_index(drop=True)
        self.berth_1 = shuffled_buses.iloc[:n]['ServiceNo'].tolist()
        self.berth_2 = shuffled_buses.iloc[n:]['ServiceNo'].tolist()
        self.done = True
        return self._get_state()
    '''
    
    def generate_service_time(self, vehicle_type):
        """
        Poisson distribution
        """
        if vehicle_type == 'SD':
            service_time = np.random.poisson(lam=40)
        else:
            service_time = np.random.poisson(lam=60)
       
        return service_time

    def calculate_delay(self, berth, df):
        """
        Calculates the delay for a given berth.
        """
        daycnt = len(df['Date'].unique())
        berth_df = df[df['ServiceNo'].isin(berth)]
        berth_df = berth_df.sort_values(['DateTime'])

        grouped = berth_df.groupby('Date')

        dateDelayPair = []

        for date, group in grouped:

            queue = deque()  # Queue for waiting vehicles
            delay = 0

            # each day
            for _, row in group.iterrows():
                arrival_time = row['DateTime']
                queue.append(arrival_time)
                
            if len(queue) >= 2:
            # Two service zones, serviceZone[i] = K, means the i-th service zone has a veh will left at K-th second
                serviceZone = [queue[0]+60 * pd.Timedelta(seconds=1), queue[1]+60 * pd.Timedelta(seconds=1)]
                queue.popleft()
                queue.popleft()

            # Process the queue
            elif len(queue) == 1:
                # 如果队列中只有一个车辆，则只使用一个服务区
                serviceZone = [queue[0] + 60 * pd.Timedelta(seconds=1)]
                queue.popleft()
                
            while queue:
                arrival_time = queue.popleft()

                # Find the service zone to enter
                # 1. the min_left_time < arrival_time, no need to wait, delay = 0
                # 2. the min_left_time >= arrival_time, wait until the min_left_time
                min_left_time, min_idx = min(serviceZone), serviceZone.index(min(serviceZone))
                if min_left_time >= arrival_time:
                    delay += (min_left_time - arrival_time).total_seconds()
                # Update the service zone
                serviceZone[min_idx] = arrival_time + 60 * pd.Timedelta(seconds=1)

            dateDelayPair.append((date, delay))

        # Plot the results
        dates = [date for date, _ in dateDelayPair]
        delays = [delay  for _, delay in dateDelayPair]


        # Average delay per day
        average_delay = sum(delays)/daycnt

        return torch.tensor(average_delay, device=self.device)
        
    def calculate_reward(self, alpha, beta, theta, berth_1, berth_2, df):
        """
        Calculates the reward based on the delays and berth distribution.
        """
        delay_berth_1 = self.calculate_delay(berth_1, df)
        delay_berth_2 = self.calculate_delay(berth_2, df)
        reward = 2000 - theta * abs(len(self.berth_1) - len(self.berth_2)) - alpha * delay_berth_1 - beta * delay_berth_2
        return reward